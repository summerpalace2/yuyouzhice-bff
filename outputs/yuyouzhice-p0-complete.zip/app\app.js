const GOLDEN_PROMPT = '我和朋友两个人，第一次去重庆，周五下午到，周日下午回。想去城市地标和有重庆特色的地方，喜欢拍照和吃本地菜，不想走太多路，预算每人每天 500 元左右。';

const state = {
  view: 'home', prompt: GOLDEN_PROMPT, trip: null, sessionId: null, detail: null,
  loginOpen: false, authToken: null, user: null, loading: false, toast: '',
  replan: null, reason: '少走路', memoryProposal: null, savedTrips: null, health: null,
  loginError: '', pendingAfterLogin: null
};

const app = document.querySelector('#app');

async function request(path, options = {}) {
  const headers = { 'content-type': 'application/json', ...(options.headers || {}) };
  if (state.authToken) headers.authorization = `Bearer ${state.authToken}`;
  const response = await fetch(path, { ...options, headers });
  const data = await response.json();
  if (!response.ok) throw Object.assign(new Error(data.message || '请求失败'), { data, status: response.status });
  return data;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
}

function factClass(status) { return status === '未知' ? 'fact-unknown' : status === '动态' ? 'fact-dynamic' : status === '冲突' ? 'fact-conflict' : ''; }
function factLines(facts = []) { return facts.map((item) => `<div class="fact-line"><span>${escapeHtml(item.label)}</span><b class="${factClass(item.status)}">${escapeHtml(item.value)}</b></div>`).join(''); }
function citations(items = []) { return items.map((item) => `<span class="citation" title="${escapeHtml(item.note || '')}">${escapeHtml(item.title)} · ${escapeHtml(item.endpoint)}</span>`).join(''); }

function header() {
  const nav = [['home', '首页'], ['planning', 'AI 规划'], ['trips', '我的行程'], ['admin', '状态管理']];
  return `<header class="topbar shell"><div class="brand" data-action="go" data-view="home"><div class="brand-mark">渝</div><div><div class="brand-name">渝游智策</div><div class="brand-note">重庆旅行决策助手</div></div></div><nav class="nav">${nav.map(([id, label]) => `<button class="${state.view === id ? 'active' : ''}" data-action="go" data-view="${id}">${label}</button>`).join('')}<button class="user-button" data-action="login"><span class="user-dot">${state.user ? '游' : '未'}</span>${state.user ? '已登录' : '登录保存'}</button></nav></header>`;
}

function homeView() {
  return `<main class="page shell"><section class="hero"><div><div class="eyebrow">重庆 · 山城 · 慢一点也没关系</div><h1>让每一次<br /><em>重庆出发</em>都更笃定</h1><p class="lede">把你的时间、兴趣、体力与预算交给渝游智策，先得到一份能解释、能核验、能随时调整的行程。</p><div class="prompt-box"><textarea id="prompt-input" aria-label="旅行需求">${escapeHtml(state.prompt)}</textarea><div class="prompt-footer"><span class="hint">匿名即可开始 · 事实状态会被明确标注</span><button class="primary" data-action="plan">开始 AI 规划 →</button></div></div><div class="chip-row"><button class="chip" data-action="fill" data-value="${escapeHtml(GOLDEN_PROMPT)}">使用示例需求</button><button class="chip" data-action="fill" data-value="少走路、室内为主、预算友好">少走路</button><button class="chip" data-action="fill" data-value="拍照、夜景、重庆本地菜">拍照与本地菜</button></div></div><div class="hero-visual"><div class="visual-tag">山城第一版计划</div><div class="visual-caption"><strong>从解放碑到洪崖洞</strong><span>把想去的地方，变成可以行动的顺序</span></div></div></section><section class="feature-strip"><div class="feature"><div class="feature-icon">◈</div><div><strong>先理解，再规划</strong><span>把时间、偏好、预算整理成可编辑约束。</span></div></div><div class="feature"><div class="feature-icon">◇</div><div><strong>每个判断都有出处</strong><span>动态、未知、冲突事实不被藏起来。</span></div></div><div class="feature"><div class="feature-icon">↗</div><div><strong>只改你要改的地方</strong><span>局部重规划保留原计划的稳定部分。</span></div></div></section></main>`;
}

function slots() {
  return `<aside class="panel"><div class="panel-pad"><div class="panel-title">已识别的旅行约束</div><div class="slot"><div class="slot-mark">人</div><div><strong>2 位同行</strong><span>朋友 · 首次到访</span></div></div><div class="slot"><div class="slot-mark">时</div><div><strong>周五至周日</strong><span>两天一夜 · 周五下午到达</span></div></div><div class="slot"><div class="slot-mark">趣</div><div><strong>地标 + 拍照 + 本地菜</strong><span>城市体验优先</span></div></div><div class="slot"><div class="slot-mark">步</div><div><strong>少走路</strong><span>步行与公交动态优化</span></div></div><div class="slot"><div class="slot-mark">钱</div><div><strong>约 500 元 / 人 / 天</strong><span>预算为软约束</span></div></div></div></aside>`;
}

function stopCard(stop) {
  return `<article class="stop"><div class="stop-icon tone-${escapeHtml(stop.tone)}">${escapeHtml(stop.icon)}</div><div><div class="stop-meta">${escapeHtml(stop.time)} · ${escapeHtml(stop.duration)} · ${escapeHtml(stop.district)}</div><h3>${escapeHtml(stop.name)}</h3><p>${escapeHtml(stop.summary)}</p><div class="chip-row"><span class="chip">${escapeHtml(stop.walk)}</span><span class="chip">事实待核验</span></div></div><div class="stop-actions"><button class="ghost" data-action="detail" data-id="${escapeHtml(stop.venueId)}">查看详情</button><button class="secondary" data-action="open-replan" data-id="${escapeHtml(stop.id)}">替换此站</button></div></article>`;
}

function planView() {
  if (!state.trip) return `<main class="page shell"><div class="panel trip-empty"><div><div class="empty-symbol">行</div><h2>还没有行程草稿</h2><p class="muted">先从首页输入你的重庆旅行需求。</p><button class="primary" data-action="go" data-view="home">回到首页</button></div></div></main>`;
  const trip = state.trip;
  return `<main class="page shell"><div class="section-title"><div><div class="eyebrow">已生成 · 可继续调整</div><h2>你的重庆行程</h2><p>先看结构，再决定哪些事实需要你确认。</p></div><div><button class="secondary" data-action="save">保存这份行程</button></div></div><div class="workspace-grid">${slots()}<section class="panel"><div class="plan-header"><div><h2>${escapeHtml(trip.title)}</h2><p>${escapeHtml(trip.subtitle)}</p></div><span class="status-pill">${escapeHtml(trip.sourceMode)}</span></div>${trip.days.map((day) => `<div class="day-block"><div class="day-head"><strong>${escapeHtml(day.dateLabel)}</strong><span>${escapeHtml(day.weather.value)}</span></div>${day.stops.map(stopCard).join('')}</div>`).join('')}<div class="facts-box"><strong>事实状态总览</strong>${factLines([fact('已确认', trip.summary.confirmed.join('、'), '已核验'), fact('动态数据', trip.summary.dynamic.join('、'), '动态'), fact('未知待确认', trip.summary.unknown.join('、'), '未知'), fact('当前冲突', trip.summary.conflict.join('、'), '冲突')])}<div class="chip-row">${citations(trip.citations)}</div></div></section><aside class="panel evidence-card"><div class="panel-title">来源与路线</div><div class="map-art"><i class="map-pin pin-a"></i><i class="map-pin pin-b"></i></div><div class="legend"><span>解放碑</span><span>洪崖洞</span></div><div class="evidence-item"><span class="evidence-bullet">01</span><span>POI、景点详情与输入提示由高德接口适配器承接。</span></div><div class="evidence-item"><span class="evidence-bullet">02</span><span>步行路线与公交路线分开引用，不混淆交通方式。</span></div><div class="evidence-item"><span class="evidence-bullet">03</span><span>当前没有服务端密钥时，以演示回退模式运行。</span></div><div class="notice">这一版会把“未知”直接留在卡片上。你确认后再保存，减少被错误事实带偏。</div></aside></div></main>`;
}

function detailView() {
  const detail = state.detail;
  if (!detail) return `<main class="page shell"><div class="panel trip-empty"><p>正在读取景点信息……</p></div></main>`;
  return `<main class="page shell"><div class="detail-layout"><div class="detail-hero"><div class="vertical">山城有光</div></div><section class="detail-copy"><button class="ghost" data-action="go" data-view="planning">← 返回行程</button><div class="eyebrow">景点详情 · ${escapeHtml(detail.district)}</div><h1>${escapeHtml(detail.name)}</h1><p class="intro">${escapeHtml(detail.intro)}</p><div>${detail.tags.map((tag) => `<span class="tag">${escapeHtml(tag)}</span>`).join('')}</div><div class="detail-facts">${detail.facts.map((factItem) => `<div class="detail-fact"><strong>${escapeHtml(factItem.label)}</strong><div class="${factClass(factItem.status)}"><b>${escapeHtml(factItem.value)}</b><small>${escapeHtml(factItem.note)}</small></div></div>`).join('')}</div><div class="chip-row">${citations(detail.citations)}</div></section></div></main>`;
}

function tripsView() {
  if (!state.user) return `<main class="page shell"><div class="panel trip-empty"><div><div class="empty-symbol">存</div><h2>登录后查看已保存行程</h2><p class="muted">匿名规划不会自动出现在这里，登录只在你选择保存时发生。</p><button class="primary" data-action="login">登录并查看</button></div></div></main>`;
  if (state.savedTrips === null) return `<main class="page shell"><div class="panel trip-empty"><p>正在读取你的行程……</p></div></main>`;
  if (!state.savedTrips.length) return `<main class="page shell"><div class="panel trip-empty"><div><div class="empty-symbol">空</div><h2>还没有保存的行程</h2><p class="muted">从首页开始一次重庆规划，确认后再保存。</p><button class="primary" data-action="go" data-view="home">开始规划</button></div></div></main>`;
  return `<main class="page shell"><div class="section-title"><div><div class="eyebrow">只显示你的真实保存</div><h2>我的行程</h2><p>演示草稿不会混入这里。</p></div></div>${state.savedTrips.map((item) => `<article class="panel trip-card"><div><div class="eyebrow">保存于 ${new Date(item.savedAt).toLocaleString('zh-CN')}</div><h3>${escapeHtml(item.trip.title)}</h3><p>${escapeHtml(item.trip.subtitle)} · 第 ${item.trip.version} 版</p></div><button class="secondary" data-action="load-saved" data-id="${escapeHtml(item.id)}">打开行程</button></article>`).join('')}</main>`;
}

function adminView() {
  if (!state.health) return `<main class="page shell"><div class="panel trip-empty"><p>正在读取服务状态……</p></div></main>`;
  return `<main class="page shell"><div class="section-title"><div><div class="eyebrow">运行状态</div><h2>服务与来源管理</h2><p>这里展示当前运行边界，不把演示数据标成实时数据。</p></div><button class="secondary" data-action="health">刷新状态</button></div><div class="admin-grid"><section class="panel panel-pad"><div class="panel-title">服务状态</div><div class="health-row"><span>应用服务</span><b class="health-ok">正常</b></div><div class="health-row"><span>存储</span><b class="health-warn">${escapeHtml(state.health.storage)}</b></div><div class="health-row"><span>高德数据适配</span><b class="${state.health.adapter.keyConfigured ? 'health-ok' : 'health-warn'}">${escapeHtml(state.health.adapter.mode)}</b></div><div class="health-row"><span>最后检查</span><b>${new Date(state.health.time).toLocaleTimeString('zh-CN')}</b></div></section><section class="panel panel-pad"><div class="panel-title">当前接口目录</div>${state.health.adapter.endpoints.map((endpoint) => `<div class="health-row"><span>${escapeHtml(endpoint)}</span><b class="health-ok">已登记</b></div>`).join('')}</section></div></main>`;
}

function loginModal() {
  if (!state.loginOpen) return '';
  return `<div class="modal-wrap"><div class="modal"><h2>登录后保存</h2><p>登录失败不会清空当前规划草稿。演示账号：demo@cqx.com，密码：123456。</p><form data-action="login-form"><div class="form-row"><label>邮箱</label><input name="email" type="email" value="demo@cqx.com" required /></div><div class="form-row"><label>密码</label><input name="password" type="password" value="123456" required /></div>${state.loginError ? `<div class="notice">${escapeHtml(state.loginError)}</div>` : ''}<div class="modal-actions"><button type="button" class="secondary" data-action="close-login">取消</button><button type="submit" class="primary">登录继续</button></div></form></div></div>`;
}

function replanModal() {
  if (!state.replan) return '';
  const reasons = ['少走路', '下雨了', '想换室内', '时间变少'];
  return `<div class="modal-wrap"><div class="modal"><h2>只替换这一站</h2><p>会保留其它站点、日期与行程结构，只重新计算你选中的站点。</p><div class="reason-grid">${reasons.map((reason) => `<button class="chip ${state.reason === reason ? 'selected' : ''}" data-action="reason" data-reason="${reason}">${reason}</button>`).join('')}</div><div class="notice">当前选择：${escapeHtml(state.reason)}。推荐替换为“重庆中国三峡博物馆”，公交优先，减少步行。</div><div class="modal-actions"><button class="secondary" data-action="close-replan">先不换</button><button class="primary" data-action="confirm-replan">确认局部重规划</button></div></div></div>`;
}

function memoryModal() {
  if (!state.memoryProposal) return '';
  return `<div class="modal-wrap"><div class="modal"><h2>记住这个偏好吗？</h2><p>${escapeHtml(state.memoryProposal.copy)} 记住后，之后的规划会优先参考；仅本次则不会写入偏好。</p><div class="modal-actions"><button class="secondary" data-action="memory-once">仅本次</button><button class="primary" data-action="memory-save">记住偏好</button></div></div></div>`;
}

function render() {
  const views = { home: homeView, planning: planView, detail: detailView, trips: tripsView, admin: adminView };
  app.innerHTML = `${header()}<div class="${state.loading ? 'loading' : ''}">${views[state.view]()}</div>${loginModal()}${replanModal()}${memoryModal()}${state.toast ? `<div class="toast">${escapeHtml(state.toast)}</div>` : ''}`;
  window.setTimeout(() => { state.toast = ''; if (!state.loginOpen && !state.replan && !state.memoryProposal) render(); }, 2600);
}

function toast(message) { state.toast = message; render(); }
async function plan() {
  state.prompt = document.querySelector('#prompt-input')?.value || state.prompt;
  state.loading = true; state.view = 'planning'; render();
  try { const data = await request('/api/plan', { method: 'POST', body: JSON.stringify({ prompt: state.prompt }) }); state.sessionId = data.sessionId; state.trip = data.trip; toast('行程已生成，先看看哪些事实需要确认。'); }
  catch (error) { state.view = 'home'; toast(error.message); }
  finally { state.loading = false; render(); }
}

async function openDetail(id) { state.loading = true; state.view = 'detail'; render(); try { state.detail = (await request(`/api/attractions/${id}`)).detail; } catch (error) { toast(error.message); } finally { state.loading = false; render(); } }
async function confirmReplan() { state.loading = true; render(); try { const data = await request('/api/replan', { method: 'POST', body: JSON.stringify({ sessionId: state.sessionId, targetStopId: state.replan, reason: state.reason }) }); state.trip = data.trip; state.replan = null; state.memoryProposal = data.memoryProposal; toast(`已替换 1 个站点，其余 ${data.unchangedStops.length} 个站点保持不变。`); } catch (error) { toast(error.message); } finally { state.loading = false; render(); } }
async function saveTrip() { if (!state.trip) return toast('还没有可保存的行程。'); if (!state.authToken) { state.pendingAfterLogin = 'save'; state.loginOpen = true; return render(); } try { await request('/api/trips/save', { method: 'POST', body: JSON.stringify({ trip: state.trip }) }); toast('已保存到我的行程。'); } catch (error) { toast(error.message); } }
async function loadTrips() { if (!state.user) return; state.savedTrips = null; render(); try { state.savedTrips = (await request('/api/trips')).trips; } catch (error) { toast(error.message); } render(); }
async function health() { state.health = await request('/api/health'); render(); }

app.addEventListener('input', (event) => { if (event.target.id === 'prompt-input') state.prompt = event.target.value; });
app.addEventListener('submit', async (event) => { if (event.target.dataset.action !== 'login-form') return; event.preventDefault(); const form = new FormData(event.target); state.loading = true; state.loginError = ''; render(); try { const data = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: form.get('email'), password: form.get('password') }) }); state.authToken = data.token; state.user = data.user; state.loginOpen = false; const after = state.pendingAfterLogin; state.pendingAfterLogin = null; toast(data.message); if (after === 'save') await saveTrip(); if (after === 'memory') await rememberPreference(); } catch (error) { state.loginError = error.message; } finally { state.loading = false; render(); } });
app.addEventListener('click', async (event) => {
  const target = event.target.closest('[data-action]'); if (!target) return;
  const action = target.dataset.action;
  if (action === 'go') { state.view = target.dataset.view; if (state.view === 'trips') await loadTrips(); if (state.view === 'admin') await health(); render(); }
  if (action === 'login') { state.loginOpen = true; state.loginError = ''; render(); }
  if (action === 'close-login') { state.loginOpen = false; render(); }
  if (action === 'fill') { state.prompt = target.dataset.value; const input = document.querySelector('#prompt-input'); if (input) input.value = state.prompt; }
  if (action === 'plan') await plan();
  if (action === 'detail') await openDetail(target.dataset.id);
  if (action === 'open-replan') { state.replan = target.dataset.id; render(); }
  if (action === 'close-replan') { state.replan = null; render(); }
  if (action === 'reason') { state.reason = target.dataset.reason; render(); }
  if (action === 'confirm-replan') await confirmReplan();
  if (action === 'save') await saveTrip();
  if (action === 'health') await health();
  if (action === 'memory-once') { state.memoryProposal = null; toast('仅本次调整已保留，不写入长期偏好。'); }
  if (action === 'memory-save') { if (!state.authToken) { state.pendingAfterLogin = 'memory'; state.memoryProposal = null; state.loginOpen = true; render(); } else await rememberPreference(); }
  if (action === 'load-saved') { const item = state.savedTrips?.find((trip) => trip.id === target.dataset.id); if (item) { state.trip = item.trip; state.view = 'planning'; render(); } }
});

async function rememberPreference() { if (!state.authToken) return; try { await request('/api/preferences', { method: 'POST', body: JSON.stringify({ value: state.reason }) }); state.memoryProposal = null; toast('已记住“少走路”偏好。'); } catch (error) { toast(error.message); } }

render();
