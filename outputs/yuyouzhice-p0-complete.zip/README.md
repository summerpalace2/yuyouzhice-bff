# 渝游智策｜重庆旅行决策助手

这是基于用户提供的 PRD V1.0 与《AMAP Web Service API 接口目录》实现的 P0 可运行版本。当前实现不是静态 UI：它包含匿名规划、结构化行程、事实状态、来源引用、景点详情、局部重规划、记忆提案、登录回跳、保存与我的行程、服务状态页。

## 启动

无需安装第三方依赖，直接运行：

```bash
npm start
```

打开 `http://localhost:3000`。

如果需要接入高德 Web Service API，在启动前设置服务端环境变量 `AMAP_KEY`；如使用安全密钥，再设置 `AMAP_SECURITY_KEY`。密钥只在服务端读取，不写入前端。

没有密钥时应用使用明确标注的“演示回退模式”，不会把演示数据伪装成实时高德事实。

## 验证

```bash
npm run check
npm run test:e2e
npm run test:auth
npm run test:acceptance
```

## 主要接口

适配器登记并使用用户接口目录中的：

- `/v5/place/text`
- `/v5/place/detail`
- `/v3/geocode/geo`
- `/v3/geocode/regeo`
- `/v5/direction/walking`
- `/v5/direction/transit/integrated`
- `/v3/assistant/inputtips`
- `/v3/weather/weatherInfo`

前端所有核心文案为中文。未知、动态、冲突状态在行程卡片和详情中显式展示；“我的行程”只读取登录用户实际保存的数据，不混入演示草稿。
