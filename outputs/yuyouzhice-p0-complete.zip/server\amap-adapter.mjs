/*
 * 渝游智策｜高德适配边界：产品事实来源是用户提供的接口目录。
 * 没有服务端密钥或接口不可用时，只返回“演示回退”标记，不冒充实时高德事实。
 */
const API_BASE = 'https://restapi.amap.com';

export const AMAP_ENDPOINTS = Object.freeze({
  poiSearch: '/v5/place/text',
  poiDetail: '/v5/place/detail',
  geocode: '/v3/geocode/geo',
  reGeocode: '/v3/geocode/regeo',
  walking: '/v5/direction/walking',
  transit: '/v5/direction/transit/integrated',
  inputTips: '/v3/assistant/inputtips',
  weather: '/v3/weather/weatherInfo'
});

function configured() {
  return Boolean(process.env.AMAP_KEY);
}

function buildQuery(params = {}) {
  const query = new URLSearchParams({ ...params, key: process.env.AMAP_KEY || '' });
  if (process.env.AMAP_SECURITY_KEY) query.set('jscode', process.env.AMAP_SECURITY_KEY);
  return query;
}

export async function requestAmap(path, params = {}, { timeoutMs = 4500 } = {}) {
  if (!configured()) {
    return { ok: false, source: '演示回退', reason: '未配置高德服务端密钥', data: null };
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${API_BASE}${path}?${buildQuery(params)}`, { signal: controller.signal });
    const data = await response.json();
    if (!response.ok || data.status !== '1') {
      return { ok: false, source: '高德接口', reason: data.info || `HTTP ${response.status}`, data };
    }
    return { ok: true, source: '高德接口', reason: null, data };
  } catch (error) {
    return { ok: false, source: '演示回退', reason: error.name === 'AbortError' ? '高德接口超时' : '高德接口暂不可用', data: null };
  } finally {
    clearTimeout(timer);
  }
}

export const amap = {
  poiSearch: (keywords, city = '重庆市') => requestAmap(AMAP_ENDPOINTS.poiSearch, {
    keywords, city, citylimit: 'true', page_size: '10', show_fields: 'business,navi,photos'
  }),
  poiDetail: (id) => requestAmap(AMAP_ENDPOINTS.poiDetail, { id, show_fields: 'business,navi,photos' }),
  geocode: (address) => requestAmap(AMAP_ENDPOINTS.geocode, { address, city: '重庆市' }),
  reGeocode: (location) => requestAmap(AMAP_ENDPOINTS.reGeocode, { location, extensions: 'all' }),
  walking: (origin, destination) => requestAmap(AMAP_ENDPOINTS.walking, {
    origin, destination, show_fields: 'cost,navi,polyline'
  }),
  transit: (origin, destination) => requestAmap(AMAP_ENDPOINTS.transit, {
    origin, destination, city: '重庆市', strategy: '0', show_fields: 'cost,polyline'
  }),
  inputTips: (keywords) => requestAmap(AMAP_ENDPOINTS.inputTips, { keywords, city: '重庆市' }),
  weather: () => requestAmap(AMAP_ENDPOINTS.weather, { city: '500000', extensions: 'all' })
};

export function adapterStatus() {
  return {
    provider: '高德 Web Service API',
    mode: configured() ? '已配置接口模式' : '演示回退模式',
    keyConfigured: configured(),
    endpoints: Object.values(AMAP_ENDPOINTS)
  };
}
