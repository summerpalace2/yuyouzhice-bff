import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { adapterStatus, amap } from './amap-adapter.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');
const APP_DIR = path.join(ROOT, 'app');
const PORT = Number(process.env.PORT || 3000);

const sessions = new Map();
const tokens = new Map();
const tripsByUser = new Map();
const preferencesByUser = new Map();
let nextTripId = 1;

const citation = (title, endpoint, status = '已核验') => ({
  title,
  publisher: '高德开放平台',
  endpoint,
  status,
  note: status === '已核验' ? '接口字段可追溯，动态值以查询时返回为准。' : '当前为用户确认前的保守状态。'
});

function fact(label, value, status, note, citations = []) {
  return { label, value, status, note, citations };
}

function makeStop({ id, name, district, time, duration, icon, tone, summary, walk, venueId, detail }) {
  return {
    id, name, district, time, duration, icon, tone, summary, walk, venueId,
    detail,
    facts: [
      fact('开放与营业', '未知·需实时确认', '未知', '未拿到当前开放状态，不在规划中做确定承诺。', [citation('高德 POI 详情接口', '/v5/place/detail', '待查询')]),
      fact('门票与消费', '未知·需用户确认', '未知', '价格与预约规则可能变化，保留为确认项。', [citation('用户确认项', '用户输入', '待确认')]),
      fact('到达方式', walk, '动态', '路线由高德步行/公交接口查询后生成。', [citation('高德路径规划接口', walk.includes('少走') ? '/v5/direction/walking' : '/v5/direction/transit/integrated')])
    ],
    citations: [citation(`${name} POI 与路线来源`, '/v5/place/text'), citation('路线核验入口', '/v5/direction/walking')]
  };
}

function demoTrip(version = 1) {
  return {
    id: `draft-cq-${version}`,
    version,
    title: '重庆两天一夜·山城人文线',
    subtitle: '少走路优先 · 首次到访 · 美食待确认',
    sourceMode: adapterStatus().mode,
    factPolicy: '动态 / 未知 / 冲突事实显式标注',
    days: [
      {
        day: 1, dateLabel: '第一天 · 城市记忆',
        weather: fact('天气', '动态查询中', '动态', '天气必须在出行前再次确认。', [citation('高德天气接口', '/v3/weather/weatherInfo')]),
        stops: [
          makeStop({ id: 'day1-jiefangbei', name: '解放碑步行街', district: '渝中区', time: '15:30', duration: '约 90 分钟', icon: '碑', tone: 'red', summary: '城市地标与街区热身，先把节奏放慢。', walk: '少走路', venueId: 'cq-jiefangbei', detail: '适合作为第一站，先完成城市地标认知。' }),
          makeStop({ id: 'day1-hongyadong', name: '洪崖洞', district: '渝中区', time: '19:00', duration: '约 90 分钟', icon: '灯', tone: 'gold', summary: '夜景主场，保留弹性时间应对人流与排队。', walk: '步行约 12 分钟', venueId: 'cq-hongyadong', detail: '以夜景和临江层次为核心，动态拥挤度不作承诺。' })
        ]
      },
      {
        day: 2, dateLabel: '第二天 · 博物馆与城市切面',
        weather: fact('天气', '动态查询中', '动态', '天气必须在出行前再次确认。', [citation('高德天气接口', '/v3/weather/weatherInfo')]),
        stops: [
          makeStop({ id: 'day2-museum', name: '重庆中国三峡博物馆', district: '渝中区', time: '10:00', duration: '约 120 分钟', icon: '馆', tone: 'blue', summary: '用更稳定的室内时段承接第二天上午。', walk: '公交优先', venueId: 'cq-museum', detail: '室内内容丰富，预约与开放时间需在出发前核验。' }),
          makeStop({ id: 'day2-liziba', name: '李子坝轻轨站', district: '渝中区', time: '14:30', duration: '约 60 分钟', icon: '轨', tone: 'green', summary: '用一个交通切面收束重庆城市体验。', walk: '公交优先', venueId: 'cq-liziba', detail: '停留时间短、识别度高，作为收束站点更稳妥。' })
        ]
      }
    ],
    summary: {
      confirmed: ['路线骨架', '景点顺序', '两日节奏'],
      dynamic: ['天气', '实时人流', '公交与步行耗时'],
      unknown: ['门票与预约', '营业时间', '最终消费'],
      conflict: ['洪崖洞夜间拥挤与停留时长需现场决策']
    },
    citations: [citation('POI 搜索', '/v5/place/text'), citation('步行路线', '/v5/direction/walking'), citation('公交路线', '/v5/direction/transit/integrated')]
  };
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function json(res, status, payload) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(payload));
}

async function body(req) {
  let raw = '';
  for await (const chunk of req) raw += chunk;
  if (!raw) return {};
  try { return JSON.parse(raw); } catch { return {}; }
}

function authUser(req) {
  const value = req.headers.authorization || '';
  const token = value.startsWith('Bearer ') ? value.slice(7) : '';
  return tokens.get(token) || null;
}

function tripForSession(sessionId) {
  const session = sessions.get(sessionId);
  return session?.trip || null;
}

function createSession(input = '') {
  const id = `session-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
  const trip = demoTrip(1);
  const session = { id, input, trip, createdAt: new Date().toISOString(), replanHistory: [] };
  sessions.set(id, session);
  return session;
}

async function api(req, res, url) {
  if (req.method === 'GET' && url.pathname === '/api/health') {
    return json(res, 200, { ok: true, service: '渝游智策服务', time: new Date().toISOString(), adapter: adapterStatus(), storage: '内存演示存储' });
  }
  if (req.method === 'GET' && url.pathname === '/api/session') {
    return json(res, 200, { ok: true, anonymous: true, trip: null, message: '当前为匿名状态，规划后可保存草稿。' });
  }
  if (req.method === 'POST' && url.pathname === '/api/plan') {
    const input = await body(req);
    const session = createSession(String(input.prompt || ''));
    return json(res, 200, { ok: true, sessionId: session.id, trip: clone(session.trip), phase: '已生成结构化行程', source: adapterStatus() });
  }
  if (req.method === 'GET' && url.pathname.startsWith('/api/attractions/')) {
    const id = url.pathname.split('/').pop();
    const details = {
      'cq-hongyadong': { name: '洪崖洞', district: '渝中区', intro: '重庆山城夜景代表性场景。界面只呈现可追溯与待确认信息。', tags: ['夜景', '临江', '人流动态'], facts: [fact('开放时间', '未知·需实时确认', '未知', '不从静态文案推断营业状态。'), fact('实时人流', '动态·暂未查询', '动态', '需要在出行前或到达前查询。'), fact('预约与门票', '未知·需用户确认', '未知', '不在产品中虚构价格或预约规则。')], citations: [citation('高德 POI 详情接口', '/v5/place/detail', '待查询'), citation('高德天气接口', '/v3/weather/weatherInfo', '待查询')] },
      'cq-museum': { name: '重庆中国三峡博物馆', district: '渝中区', intro: '适合承接第二天上午的室内人文站点。', tags: ['室内', '人文', '预约待确认'], facts: [fact('开放状态', '未知·需实时确认', '未知', '出行前核验。'), fact('预约规则', '未知·需用户确认', '未知', '不从旧数据推断。'), fact('到达方式', '公交优先', '动态', '路线由高德接口计算。')], citations: [citation('高德 POI 搜索接口', '/v5/place/text'), citation('高德公交路径接口', '/v5/direction/transit/integrated')] },
      'cq-jiefangbei': { name: '解放碑步行街', district: '渝中区', intro: '作为第一站，完成城市地标认知与节奏热身。', tags: ['城市地标', '街区', '少走路'], facts: [fact('实时拥挤度', '动态·暂未查询', '动态', '现场情况以查询结果为准。'), fact('消费', '未知·需用户确认', '未知', '美食与消费不做虚假承诺。')], citations: [citation('高德 POI 搜索接口', '/v5/place/text')] },
      'cq-liziba': { name: '李子坝轻轨站', district: '渝中区', intro: '用交通切面收束重庆城市体验。', tags: ['交通切面', '短停留', '城市观察'], facts: [fact('最佳停留时长', '建议约 60 分钟', '建议', '属于行程建议，不是实时事实。'), fact('现场情况', '动态·需确认', '动态', '到达时再次判断。')], citations: [citation('高德 POI 搜索接口', '/v5/place/text'), citation('高德步行路径接口', '/v5/direction/walking')] }
    };
    return json(res, 200, { ok: true, detail: details[id] || details['cq-hongyadong'] });
  }
  if (req.method === 'POST' && url.pathname === '/api/replan') {
    const input = await body(req);
    const session = sessions.get(input.sessionId);
    if (!session) return json(res, 404, { ok: false, message: '规划草稿已失效，请重新生成。' });
    const oldTrip = clone(session.trip);
    const targetStopId = String(input.targetStopId || 'day1-hongyadong');
    const reason = String(input.reason || '少走路');
    const replacement = makeStop({ id: targetStopId, name: '重庆中国三峡博物馆', district: '渝中区', time: '19:00', duration: '约 90 分钟', icon: '馆', tone: 'blue', summary: '根据你的“少走路”偏好，换成更稳定的室内站点。', walk: '公交优先', venueId: 'cq-museum', detail: '这是局部替换，仅改变目标站点。原有其它站点保持不变。' });
    let changed = false;
    for (const day of session.trip.days) {
      const index = day.stops.findIndex((stop) => stop.id === targetStopId);
      if (index >= 0) { day.stops[index] = replacement; changed = true; }
    }
    if (!changed) return json(res, 400, { ok: false, message: '未找到可替换站点。' });
    session.trip.version += 1;
    session.trip.id = `draft-cq-${session.trip.version}`;
    session.trip.subtitle = '局部重规划完成 · 其他站点保持不变';
    session.replanHistory.push({ targetStopId, reason, changedAt: new Date().toISOString() });
    const unchangedStops = oldTrip.days.flatMap((day) => day.stops).filter((stop) => stop.id !== targetStopId).map((stop) => stop.name);
    return json(res, 200, { ok: true, trip: clone(session.trip), changedSegments: [targetStopId], unchangedStops, memoryProposal: { type: 'preference', value: '少走路', copy: '以后规划优先安排少走路路线吗？' } });
  }
  if (req.method === 'POST' && url.pathname === '/api/auth/login') {
    const input = await body(req);
    if (input.email !== 'demo@cqx.com' || input.password !== '123456') return json(res, 401, { ok: false, message: '登录信息不匹配，草稿仍保留在当前页面。' });
    const token = `token-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const user = { id: 'user-demo', name: '重庆旅行者', email: input.email };
    tokens.set(token, user);
    if (!tripsByUser.has(user.id)) tripsByUser.set(user.id, []);
    return json(res, 200, { ok: true, token, user, message: '登录成功，可以保存当前行程。' });
  }
  if (req.method === 'POST' && url.pathname === '/api/trips/save') {
    const user = authUser(req);
    if (!user) return json(res, 401, { ok: false, message: '请先登录后保存，当前草稿不会丢失。' });
    const input = await body(req);
    if (!input.trip) return json(res, 400, { ok: false, message: '没有可保存的行程。' });
    const saved = { id: `trip-${nextTripId++}`, savedAt: new Date().toISOString(), trip: clone(input.trip) };
    tripsByUser.get(user.id).push(saved);
    return json(res, 200, { ok: true, saved, message: '行程已保存到我的行程。' });
  }
  if (req.method === 'GET' && url.pathname === '/api/trips') {
    const user = authUser(req);
    if (!user) return json(res, 401, { ok: false, message: '请登录查看已保存行程。' });
    return json(res, 200, { ok: true, trips: tripsByUser.get(user.id) || [] });
  }
  if (req.method === 'POST' && url.pathname === '/api/preferences') {
    const user = authUser(req);
    if (!user) return json(res, 401, { ok: false, message: '登录后才能记住偏好。' });
    const input = await body(req);
    const current = preferencesByUser.get(user.id) || [];
    if (input.value && !current.includes(input.value)) current.push(input.value);
    preferencesByUser.set(user.id, current);
    return json(res, 200, { ok: true, preferences: current, message: '偏好已记住，后续规划会优先参考。' });
  }
  return json(res, 404, { ok: false, message: '接口不存在。' });
}

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8' };

async function staticFile(res, pathname) {
  const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\//, '');
  const full = path.resolve(APP_DIR, relative);
  if (!full.startsWith(APP_DIR) || !existsSync(full)) return json(res, 404, { ok: false, message: '页面不存在。' });
  const content = await readFile(full);
  res.writeHead(200, { 'content-type': MIME[path.extname(full)] || 'application/octet-stream' });
  res.end(content);
}

export function createAppServer({ port = PORT } = {}) {
  return createServer(async (req, res) => {
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    try {
      if (url.pathname.startsWith('/api/')) return await api(req, res, url);
      return await staticFile(res, url.pathname);
    } catch (error) {
      console.error(error);
      return json(res, 500, { ok: false, message: '服务出现异常，请稍后重试。' });
    }
  }).listen(port);
}

export function resetDemoState() {
  sessions.clear(); tokens.clear(); tripsByUser.clear(); preferencesByUser.clear(); nextTripId = 1;
}

if (process.argv.includes('--check')) {
  console.log(JSON.stringify({ ok: true, service: '渝游智策', adapter: adapterStatus(), staticEntry: path.join('app', 'index.html') }, null, 2));
} else if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  createAppServer().on('listening', () => console.log(`渝游智策已启动：http://localhost:${PORT}`));
}
