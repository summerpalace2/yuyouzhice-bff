import { spawn } from 'node:child_process';

const port = 4311;
const server = spawn(process.execPath, ['server/index.mjs'], { env: { ...process.env, PORT: String(port) }, stdio: 'ignore' });
const base = `http://127.0.0.1:${port}`;
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function get(path, options) { const response = await fetch(`${base}${path}`, options); const data = await response.json(); if (!response.ok) throw new Error(`${path}: ${data.message}`); return data; }
try {
  await wait(180);
  const home = await fetch(`${base}/`); if (!home.ok) throw new Error('首页不可访问');
  const plan = await get('/api/plan', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: '两人周末重庆旅行，少走路，想拍照和吃本地菜。' }) });
  if (!plan.trip?.days?.length || !plan.sessionId) throw new Error('规划结果缺少行程结构');
  const replan = await get('/api/replan', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sessionId: plan.sessionId, targetStopId: 'day1-hongyadong', reason: '少走路' }) });
  if (replan.changedSegments.length !== 1 || replan.unchangedStops.length < 3) throw new Error('局部重规划边界不正确');
  console.log('端到端主链通过：匿名规划 → 局部重规划 → 其余站点保持不变');
} finally { server.kill(); }
